package org.buckybadger.g576final;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.buckybadger.dbutility.DBUtility;
import org.json.JSONObject;

import java.sql.ResultSet;
import java.util.Date;

public class CreateDamageReport extends AppCompatActivity {

    private Button submitReport;
    private JSONObject reportInfo;
    private static final String TAG = "UserSubmissionData:";
    private FusedLocationProviderClient fusedLocationClient;
    private Double lat;
    private Double lng;


    private void startMyActivity(Intent intent) {
        startActivity(intent);
    }

    //Step 2 and 3--Process Data and input into DB
    public void processReportDetails() {
        String timestamp =
                new java.text.SimpleDateFormat("MM/dd/yyyy h:mm:ss a").format(new Date());
        final EditText addMsg = (EditText) findViewById(R.id.add_msg);
        String add_msg = addMsg.getText().toString();
        add_msg = "'" + add_msg + "'";


        final Spinner damageType = (Spinner) findViewById(R.id.SpinnerDamageType);
        String damage_type = damageType.getSelectedItem().toString();
        damage_type = "'" + damage_type + "'";
        try {
            String sql = "INSERT INTO report (reporter_id, report_type, timestamp, geom, message) VALUES" +
                    "(1, 'damage', " + timestamp + ", " + "ST_GeomFromText('POINT(" + lng + " " + lat + ")', 4326)" + "," + add_msg + ")";
            DBUtility DBUtil = new DBUtility();
            DBUtil.modifyDB(sql);
            Log.d("Report SQL: ", sql);

            Integer reportInt;

            ResultSet res = DBUtil.queryDB("SELECT LAST VALUE FROM report_id_seq");
            res.next();

            reportInt = res.getInt(1);

            sql = "INSERT INTO damage_report (report_id, damage_type, add_msg) VALUES" +
                    "(" + reportInt + ", " + damage_type + ", " + add_msg + ")";
            DBUtil.modifyDB(sql);
            Log.d("damage_report SQL: ", sql);
        } catch (Exception e) {
            Log.d(TAG, e.toString());
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_damage_report);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        //Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            //Logic to handle location object
                            lat = location.getLatitude();
                            lng = location.getLongitude();


                            Log.d(TAG, "LastKnownUserLocation: " + lat + ", " + lng); //Display user's last known location in the log files for review

                        } else {
                            //Set Lat and Long to default for Augusta, GA
                            lat = 33.466;
                            lng = -81.9666;

                        }
                    }
                });

        //add variable for Submit Button
        submitReport = (Button)findViewById(R.id.submit);

        submitReport.setOnClickListener(new View.OnClickListener() { //click listener
            @Override
            public void onClick(View view) {

                //Step 1 -- Collect all items from form submission, process into JSONArray
                processReportDetails();

                //Step 4 -- Reload viewMap.class
                Intent myIntent = new Intent(CreateDamageReport.this, viewMap.class);
                startMyActivity(myIntent);
            }
        });

    }


}
